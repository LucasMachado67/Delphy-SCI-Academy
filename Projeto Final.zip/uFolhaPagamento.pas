unit uFolhaPagamento;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, DB, DBClient, ExtCtrls, Grids, DBGrids;

type
  TfrFolhaPagamento = class(TForm)
    gbFuncionario: TGroupBox;
    gbProventos: TGroupBox;
    gbDescontos: TGroupBox;
    gbResultado: TGroupBox;
    lbNome: TLabel;
    cbNome: TComboBox;
    lbCargo: TLabel;
    edCargo: TEdit;
    btCadastrarFuncionario: TButton;
    lbSalarioBase: TLabel;
    edSalarioBase: TEdit;
    lbHorasExtras: TLabel;
    lbOutros: TLabel;
    lbTotal: TLabel;
    edHoraExtra: TEdit;
    edOutros: TEdit;
    edTotalProventos: TEdit;
    lbInss: TLabel;
    edInss: TEdit;
    lbIrrf: TLabel;
    edIrrf: TEdit;
    lbValeTransp: TLabel;
    lbTotalD: TLabel;
    edValeTransp: TEdit;
    edTotalDescontos: TEdit;
    lbSalarioLiquido: TLabel;
    edSalarioLiquido: TEdit;
    btCalcular: TButton;
    btSalvar: TButton;
    btLimpar: TButton;
    pnFuncionario: TPanel;
    Label1: TLabel;
    lbCodigo: TLabel;
    edCodigo: TEdit;
    lbNomeCadatro: TLabel;
    edNomeCadastro: TEdit;
    lbCargoCadastro: TLabel;
    cbCargo: TComboBox;
    lbEndereco: TLabel;
    edEndereco: TEdit;
    lbTelefone: TLabel;
    edTelefone: TEdit;
    btSalvarCadastro: TButton;
    btFechar: TButton;
    dsFuncionario: TDataSource;
    cdsFolha: TClientDataSet;
    dsFolha: TDataSource;
    grFolha: TDBGrid;
    cdsFuncionario: TClientDataSet;
    cdsFuncionariobdCODIGO: TIntegerField;
    cdsFuncionariobdNOME: TStringField;
    cdsFuncionariobdCARGO: TIntegerField;
    cdsFuncionariobdENDERECO: TStringField;
    cdsFuncionariobdTELEFONE: TStringField;
    cdsFolhabdIDFOLHA: TIntegerField;
    cdsFolhabdIDFUNCIONARIO: TIntegerField;
    cdsFolhabdSALARIOBASE: TCurrencyField;
    cdsFolhabdHORASEXTRAS: TCurrencyField;
    cdsFolhabdOUTROS: TCurrencyField;
    cdsFolhabdTOTALPROVENTOS: TCurrencyField;
    cdsFolhabdINSS: TCurrencyField;
    cdsFolhabdIRRF: TCurrencyField;
    cdsFolhabdVALETRANSP: TCurrencyField;
    cdsFolhabdTOTALDESCONTOS: TCurrencyField;
    cdsFolhabdSALARIOLIQUIDO: TCurrencyField;
    Label2: TLabel;
    edCodigoFuncionario: TEdit;
    grFuncionario: TDBGrid;
    btConsultar: TButton;
    procedure btFecharClick(Sender: TObject);
    procedure btCadastrarFuncionarioClick(Sender: TObject);
    procedure btSalvarCadastroClick(Sender: TObject);
    procedure cbNomeSelect(Sender: TObject);
    procedure edSalarioBaseExit(Sender: TObject);
    procedure edHoraExtraExit(Sender: TObject);
    procedure edOutrosExit(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure edInssChange(Sender: TObject);
    procedure edIrrfChange(Sender: TObject);
    procedure btCalcularClick(Sender: TObject);
    procedure btLimparClick(Sender: TObject);
    procedure btSalvarClick(Sender: TObject);
    procedure edCodigoExit(Sender: TObject);
    procedure btConsultarClick(Sender: TObject);
    procedure edValeTranspChange(Sender: TObject);
  private
    wGeradorIDFolha:Integer;
    procedure pLimpaCamposFuncionario;
    procedure pLimpaCamposFolhaPagamento;
    procedure pCalculaProventos;
    procedure pCalculaDescontos;
    function  fValidaCamposFolha:Boolean;
    function  fValidaCamposCadastro:Boolean;
    function  fGeradorIdFolha:Integer;
  public
    { Public declarations }
  end;

var
  frFolhaPagamento: TfrFolhaPagamento;

implementation

{$R *.dfm}

procedure TfrFolhaPagamento.btFecharClick(Sender: TObject);
begin
  pLimpaCamposFuncionario;
  pnFuncionario.Visible := False;
  pnFuncionario.Left := 528;
  btConsultar.Visible := True;
end;

procedure TfrFolhaPagamento.btCadastrarFuncionarioClick(Sender: TObject);
begin
  pnFuncionario.Visible := True;
  pnFuncionario.Left := 40;

  //O bot�o continunava aparecendo em cima da tela
  btConsultar.Visible := False;
end;

procedure TfrFolhaPagamento.btSalvarCadastroClick(Sender: TObject);
begin
  if not fValidaCamposCadastro then
    Exit;

  cdsFuncionario.IndexFieldNames := 'bdCODIGO';
  if not cdsFuncionario.FindKey([edCodigo.Text]) then
    Begin
      cdsFuncionario.Insert;
    End
  else
    Begin
      cdsFuncionario.Edit;
    End;

    cdsFuncionariobdCODIGO.AsInteger := StrToInt(edCodigo.Text);
    cdsFuncionariobdNOME.AsString := edNomeCadastro.Text;
    cdsFuncionariobdCARGO.AsInteger := cbCargo.ItemIndex;
    cdsFuncionariobdENDERECO.AsString := edEndereco.Text;
    cdsFuncionariobdTELEFONE.AsString := edTelefone.Text;
    cdsFuncionario.Post;
    showMessage('Funcion�rio cadastrado com sucesso!');
    //Adicionando o funcion�rio no comboBox da tela principal.
    cbNome.Items.Add(edNomeCadastro.Text);
    pLimpaCamposFuncionario;
    edCodigo.SetFocus;
end;

procedure TfrFolhaPagamento.pLimpaCamposFuncionario;

begin
  edCodigo.Text := '';
  edNomeCadastro.Text := '';
  cbCargo.ItemIndex := 0;
  edEndereco.Text := '';
  edTelefone.Text := '';
end;

procedure TfrFolhaPagamento.cbNomeSelect(Sender: TObject);
begin
  btSalvar.Enabled := False;
  pLimpaCamposFolhaPagamento;
  cdsFuncionario.IndexFieldNames := 'bdNome';
  if not cdsFuncionario.FindKey([cbNome.Items[cbNome.ItemIndex]]) then
    Begin
      showMessage('Funcion�rio n�o encontrado');
      Exit
    End
  else
    Begin
      edCargo.Text := cbCargo.Items[cdsFuncionariobdCARGO.AsInteger];
      edCodigoFuncionario.Text := IntToStr(cdsFuncionariobdCODIGO.AsInteger);
    End;
    edSalarioBase.SetFocus;
end;

procedure TfrFolhaPagamento.pCalculaProventos;
begin
  //Soma todos os campos de proventos para pegar o novo valor
  edTotalProventos.Text := CurrToStr(StrToCurr(edSalarioBase.Text) +
                                     StrToCurr(edHoraExtra.Text) +
                                     StrToCurr(edOutros.Text));
end;


procedure TfrFolhaPagamento.pCalculaDescontos;
begin
  //Soma todos os campos de descontos para pegar o novo valor
  edTotalDescontos.Text := CurrToStr(StrToCurr(edInss.Text) +
                                     StrToCurr(edIrrf.Text) +
                                     StrToCurr(edValeTransp.Text));
end;

procedure TfrFolhaPagamento.edSalarioBaseExit(Sender: TObject);

begin
  pCalculaProventos;
  //Calculo de desconto do INSS
  edInss.Text := CurrToStr(StrToCurr(edSalarioBase.Text) * 0.09);
  //Calculo de desconto do IRRF
  edIrrf.Text := CurrToStr(StrToCurr(edSalarioBase.Text) * 0.15);
  //Calculo de desconto do Vale Transp
  edValeTransp.Text := CurrToStr(StrToCurr(edSalarioBase.Text) * 0.06);
  pCalculaDescontos;
end;

procedure TfrFolhaPagamento.edHoraExtraExit(Sender: TObject);
begin
  pCalculaProventos;
end;

procedure TfrFolhaPagamento.edOutrosExit(Sender: TObject);
begin
  pCalculaProventos;
end;

procedure TfrFolhaPagamento.FormCreate(Sender: TObject);
begin
  //Inicializa��o da v�riavel como 1 po�s ser� o ID do primeiro �ndice no cdsFolha
  wGeradorIDFolha := 1;
end;


function TfrFolhaPagamento.fValidaCamposFolha:Boolean;
begin
  Result := False;
  if cbNome.ItemIndex = -1 then
    Begin
      showMessage('O funcion�rio precisa estar selecionado');
      Exit
    End
  else if (edSalarioBase.Text = '') OR (StrToCurrDef(edSalarioBase.Text, 0) <= 0) then
    Begin
      showMessage('Sal�rio base inv�lido');
      edSalarioBase.SetFocus;
    End
  else if StrToCurrDef(edHoraExtra.Text, 0) < 0 then
    Begin
      showMessage('O campo hora extra est� inv�lido');
      edHoraExtra.SetFocus;
    End
  else if StrToCurrDef(edOutros.Text, 0) < 0 then
    Begin
      showMessage('O campo outros est� inv�lido');
      edOutros.SetFocus;
    End
  Else
    Result := True;
end;

procedure TfrFolhaPagamento.edInssChange(Sender: TObject);
begin
  pCalculaDescontos;
end;

procedure TfrFolhaPagamento.edIrrfChange(Sender: TObject);
begin
  pCalculaDescontos;
end;

procedure TfrFolhaPagamento.btCalcularClick(Sender: TObject);
begin
  btSalvar.Enabled := True;
  if not fValidaCamposFolha then
    Begin
      Exit
    End
  else
    Begin
      edSalarioLiquido.Text := CurrToStr(
        StrToCurr(edTotalProventos.Text) - StrToCurr(edTotalDescontos.Text))
    End;
end;

procedure TfrFolhaPagamento.pLimpaCamposFolhaPagamento;
begin
  edSalarioBase.Text := '0,00';
  edHoraExtra.Text := '0,00';
  edOutros.Text := '0,00';
  edTotalProventos.Text := '0,00';
  edTotalDescontos.Text := '0,00';
  edValeTransp.Text := '0,00';
  edInss.Text := '0,00';
  edIrrf.Text := '0,00';
  edSalarioLiquido.Text := '0,00';
  cbNome.SetFocus;
end;

procedure TfrFolhaPagamento.btLimparClick(Sender: TObject);
begin
  btSalvar.Enabled := False;
  pLimpaCamposFolhaPagamento;
end;



function TfrFolhaPagamento.fGeradorIdFolha: Integer;
begin
  Result := wGeradorIDFolha;
  Inc(wGeradorIDFolha)
end;


procedure TfrFolhaPagamento.btSalvarClick(Sender: TObject);
begin
  if not fValidaCamposFolha then
    Exit;
  cdsFolha.IndexFieldNames := 'bdIDFUNCIONARIO';
  if not cdsFolha.FindKey([edCodigoFuncionario.Text]) then
    Begin
      cdsFolha.Insert;
      cdsFolhabdIDFOLHA.AsInteger := fGeradorIdFolha;
    End
  else
    Begin
      cdsFolha.Edit;
    end;
    cdsFolhabdIDFUNCIONARIO.AsInteger := StrToInt(edCodigoFuncionario.Text);
    cdsFolhabdSALARIOBASE.AsCurrency := StrToCurr(edSalarioBase.Text);
    cdsFolhabdHORASEXTRAS.AsCurrency := StrToCurr(edHoraExtra.Text);
    cdsFolhabdOUTROS.AsCurrency := StrToCurr(edOutros.Text);
    cdsFolhabdTOTALPROVENTOS.AsCurrency := StrToCurr(edTotalProventos.Text);
    cdsFolhabdINSS.AsCurrency := StrToCurr(edInss.Text);
    cdsFolhabdIRRF.AsCurrency := StrToCurr(edIrrf.Text);
    cdsFolhabdVALETRANSP.AsCurrency := StrToCurr(edValeTransp.Text);
    cdsFolhabdTOTALDESCONTOS.AsCurrency := StrToCurr(edTotalDescontos.Text);
    cdsFolhabdSALARIOLIQUIDO.AsCurrency := StrToCurr(edSalarioLiquido.Text);
    cdsFolha.Post;
end;


procedure TfrFolhaPagamento.edCodigoExit(Sender: TObject);
begin
  cdsFuncionario.IndexFieldNames := 'bdCODIGO';
  if not cdsFuncionario.FindKey([edCodigo.Text]) then
    Begin
      Exit
    End
  else
    Begin
      edNomeCadastro.Text := cdsFuncionariobdNOME.AsString;
      cbCargo.ItemIndex := cdsFuncionariobdCARGO.AsInteger;
      edEndereco.Text := cdsFuncionariobdENDERECO.AsString;
      edTelefone.Text := cdsFuncionariobdTELEFONE.AsString;
    End;
end;

function TfrFolhaPagamento.fValidaCamposCadastro: Boolean;
begin

  Result := False;
  if (edCodigo.Text = '') OR (StrToIntDef(edCodigo.Text, 0) <= 0) then
    Begin
      ShowMessage('Campo c�digo inv�lido');
      Exit
    End
  else if edNomeCadastro.Text = '' then
    Begin
      ShowMessage('Campo nome inv�lido');
      Exit
    End
  else if cbCargo.ItemIndex <= -1 then
    Begin
      ShowMessage('Selecione o Cargo');
      Exit
    End
  else if edEndereco.Text = '' then
    Begin
      ShowMessage('Campo endere�o inv�lido');
      Exit
    End
  else if (edTelefone.Text = '') OR (StrToIntDef(edTelefone.Text, 0) <= 0) then
    Begin
      ShowMessage('Campo telefone inv�lido');
      Exit
    End
  else
    Result := True;
end;

procedure TfrFolhaPagamento.btConsultarClick(Sender: TObject);
var
  wMensagem: String;
begin
  wMensagem :=  'ID FUNCION�RIO | Sal�rio L�quido' + #13;
  cdsFolha.IndexFieldNames := 'bdIDFOLHA';
  cdsFolha.First;
  while not cdsFolha.Eof do
    Begin
      wMensagem := wMensagem + IntToStr(cdsFolhabdIDFUNCIONARIO.AsInteger) + ' | ' +
                    CurrToStr(cdsFolhabdSALARIOLIQUIDO.AsCurrency) + #13;
      cdsFolha.Next;
    End;
    showMessage(wMensagem);
    
end;

procedure TfrFolhaPagamento.edValeTranspChange(Sender: TObject);
begin
  pCalculaDescontos;
end;

end.
